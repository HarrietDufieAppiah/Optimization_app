# ____________________________________________________________________________________
#
# Pyomo: Python Optimization Modeling Objects
# Copyright (c) 2008-2026 National Technology and Engineering Solutions of Sandia, LLC
# Under the terms of Contract DE-NA0003525 with National Technology and Engineering
# Solutions of Sandia, LLC, the U.S. Government retains certain rights in this
# software.  This software is distributed under the 3-clause BSD License.
# ____________________________________________________________________________________

"This is the deprecated pyomo.core.base.template_expr module"

from pyomo.core.expr.template_expr import (
    IndexTemplate,
    _GetItemIndexer,
    TemplateExpressionError,
)
