# ____________________________________________________________________________________
#
# Pyomo: Python Optimization Modeling Objects
# Copyright (c) 2008-2026 National Technology and Engineering Solutions of Sandia, LLC
# Under the terms of Contract DE-NA0003525 with National Technology and Engineering
# Solutions of Sandia, LLC, the U.S. Government retains certain rights in this
# software.  This software is distributed under the 3-clause BSD License.
# ____________________________________________________________________________________

# The log should be imported first so that the Pyomo LogHandler can be
# set up as soon as possible
from . import log
from . import envvar

from .factory import Factory

from .fileutils import (
    Executable,
    Library,
    # The following will be deprecated soon
    register_executable,
    registered_executable,
    unregister_executable,
)
from . import config, dependencies, shutdown, timing
from .deprecation import deprecated
from .errors import DeveloperError
from ._command import pyomo_command, get_pyomo_commands

#
# declare deprecation paths for removed modules
#
from .deprecation import moved_module

moved_module('pyomo.common.getGSL', 'pyomo.common.gsl', version='6.5.0')
moved_module('pyomo.common.plugin', 'pyomo.common.plugin_base', version='6.5.0')
del moved_module
